package com.island.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class IslandService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private lateinit var view: TextView
    private lateinit var lp: WindowManager.LayoutParams

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val p = getSharedPreferences("island", MODE_PRIVATE)
        view = TextView(this).apply {
            text = "Island"; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = 200f }
        }
        // TYPE_ACCESSIBILITY_OVERLAY draws above lock screen and notification shade
        lp = WindowManager.LayoutParams(
            p.getInt("w", 300), p.getInt("h", 90),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = p.getInt("y", 20) }

        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                lp.width = (lp.width * d.scaleFactor).toInt().coerceIn(120, 1000)
                lp.height = (lp.height * d.scaleFactor).toInt().coerceIn(50, 400)
                wm.updateViewLayout(view, lp); return true
            }
        })
        var startY = 0; var startTouchY = 0f
        view.setOnTouchListener { _, e ->
            scale.onTouchEvent(e)
            if (e.pointerCount == 1 && !scale.isInProgress) when (e.action) {
                MotionEvent.ACTION_DOWN -> { startY = lp.y; startTouchY = e.rawY }
                MotionEvent.ACTION_MOVE -> { lp.y = startY + (e.rawY - startTouchY).toInt(); wm.updateViewLayout(view, lp) }
                MotionEvent.ACTION_UP -> p.edit().putInt("y", lp.y).putInt("w", lp.width).putInt("h", lp.height).apply()
            }
            true
        }
        wm.addView(view, lp)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { runCatching { wm.removeView(view) }; super.onDestroy() }
}
